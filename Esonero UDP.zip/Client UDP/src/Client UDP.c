#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define DIM_BUFFER 256

/*global variables*/
typedef struct {
			char op;
			float num1;
			float num2;
	}messagge_t;


void ClearWinSock() {

#if defined WIN32
	WSACleanup();
#endif

}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	/*WsaData's initialization*/
	WSADATA wsaData;
	int init = WSAStartup(MAKEWORD(2, 2), &wsaData);

	if (init != 0) {

		puts("\nWSAStartup () initialization error!");
		return 0;
	}

	/*Creation of the socket */
	int sock;
	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	//Evaluate for errors to make sure the socket is valid.
	if (sock < 0) {
		puts("Failure of socket creation!\n");
		return 0;
	}

	/* End creation of the socket */

	struct sockaddr_in server;
	char nameServer[DIM_BUFFER];
	int port;

	puts("\t\t\t ~CLIENT~ \n");
	puts("\nEnter the server name and port number: ");
	scanf("%s : %d",nameServer, &port );

	struct hostent *Remotehost = gethostbyname(nameServer);

	if (Remotehost == NULL) {
		puts("Name resolved incorrectly; closing the program. \n");
		return 0;
	}

	struct in_addr *ina = (struct in_addr*) Remotehost->h_addr_list[0];



	/*server address*/
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(inet_ntoa(*ina));
	server.sin_port = htons(port);

	/*end construction of the server address*/


	char echoMess[DIM_BUFFER];
	int lenght_server = sizeof(server);

	//strcpy(echoMess, "Hello!");
	sendto(sock, echoMess, sizeof(echoMess), 0, (struct sockaddr*) &server, sizeof(server));


	recvfrom(sock, echoMess, sizeof(echoMess), 0,(struct sockaddr*) &server, &lenght_server);
	/*puts ("server writes");
	puts(echoMess);*/

	/*input values*/
	 messagge_t m;
	int flag = 0;
	float result=0;


	do {

		/*initialization of input values*/
		m.op=' ';
		m.num1=0.00;
		m.num2=0.00;

		puts("\n\n!!! REMOTE CALCULATOR!!!\n");
		printf("\nEnter the operation to be performed \n"
			   "\t +: ADDITION \n"
			   "\t -: SUBTRACTION \n"
			   "\t *: MULTIPLICATION \n"
			   "\t /: DIVISION \n"
			   "\t =: TERMINATE CLIENT PROCESS\n");

		printf("Enter operation and two number: \n ");
		fflush(stdin);
		scanf(" %c %f %f", &m.op, &m.num1, &m.num2);
		if(m.op=='/' && m.num2==0){
			printf("Error number2, invalid divider \n");
			while(m.num2==0){
				printf("\nInsert correct number for division: \n");
				scanf("%f",&m.num2);
			}
		}

		/* sending strings struct*/
		if (sendto(sock,(void *) &m, sizeof(messagge_t), 0,(struct sockaddr*) &server, sizeof(server)) < 0) {
			closesocket(sock);
			puts("Sending failed; end of program. ");
			system("PAUSE");
			return 0;
		}

		/*receiving struct of processed strings*/

		if (recvfrom(sock,(void *) &m, sizeof(messagge_t), 0, (struct sockaddr*) &server, &lenght_server) < 0) {
			closesocket(sock);
			puts("Reception failed; end of program. ");
			system("PAUSE");
			return 0;
		}

		if (recvfrom(sock,(void *) &result, sizeof(float), 0, (struct sockaddr*) &server, &lenght_server) < 0) {
				closesocket(sock);
				puts("Reception failed; end of program. ");
				system("PAUSE");
				return 0;
		}

		 struct in_addr **addr_list;
			    printf("result received from : %s ", Remotehost->h_name);
			        printf("IP addresses: ");
			        addr_list = (struct in_addr **)Remotehost->h_addr_list;
			        for( int i = 0; addr_list[i] != NULL; i++) {
			            printf(" %s ", inet_ntoa(*addr_list[i]));
			        }


	    switch(m.op)
	   	{
	   					case '+' :	printf(" [ %.2f + %.2f = %.2f ]\n", m.num1,m.num2,result);
	   							    break;
	   					case '-' :	printf(" [ %.2f - %.2f = %.2f ]\n", m.num1,m.num2,result);
	   							    break;
	   					case '*' :	printf(" [ %.2f * %.2f = %.2f ]\n", m.num1,m.num2,result);
	   								break;
	   					case '/' :	printf(" [ %.2f / %.2f = %.2f ]\n", m.num1,m.num2,result);
	   								break;
	   					case '=':   puts("\nprocess finished \n");
	   								flag=1;
	   						        break;

	   					/*Control invalid operation */
	   				    default:    printf("\nInvalid operation. Send operation correct..\n");
	   				    			break;
	   	}

	} while (flag == 0); //while client loop to resume from string insertion

	/*End of connection*/

	printf ("\n");
	closesocket (sock);
	system ("pause");
	ClearWinSock();
	return 0;
}
