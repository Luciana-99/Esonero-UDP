#ifndef PROTOCOL_CLIENT_H_
#define PROTOCOL_CLIENT_H_
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define DIM_BUFFER 256

void ClearWinSock() {

#if defined WIN32
	WSACleanup();
#endif

}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	/*WsaData's initialization*/
	WSADATA wsaData;
	int init = WSAStartup(MAKEWORD(2, 2), &wsaData);

	if (init != 0) {

		puts("\nWSAStartup () initialization error!");
		return 0;
	}

	/*Creation of the socket */
	int sock;
	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);

	if (sock < 0) {
		puts("Failure of socket creation!\n");
		return 0;
	}

	struct sockaddr_in server;
	char nameServer[DIM_BUFFER];
	int port;

	puts("\t\t\t ~CLIENT~ \n");
	puts("\nEnter the server name and port number: ");
	scanf("%s : %d",nameServer, &port );

	struct hostent *Remotehost = gethostbyname(nameServer);

	if (Remotehost == NULL) {
		puts("Name resolved incorrectly; closing the program. \n");
		return 0;
	}

	struct in_addr *ina = (struct in_addr*) Remotehost->h_addr_list[0];



	/*Socket server*/
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(inet_ntoa(*ina));
	server.sin_port = htons(port);


	system ("pause");
	ClearWinSock();
	return 0;
}

#endif /* PROTOCOL_CLIENT_H_ */
