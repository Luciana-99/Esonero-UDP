#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define DIM_BUFFER 256
#define PORT 56700

/*global variables*/

typedef struct {
		char op;
		float num1;
		float num2;
	}messagge_t;

	float result=0;

	/* function prototypes */

	float add(float number1, float number2);
	float sub(float number1, float number2);
	float mult(float number1, float number2);
	float division(float number1, float number2);

void ClearWinSock() {

#if defined WIN32
	WSACleanup();
#endif

}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	/*WsaData's initialization*/
	WSADATA wsaData;
	int init = WSAStartup(MAKEWORD(2, 2), &wsaData);

	if (init != 0) {

		puts("\nWSAStartup () initialization error!");
		return 0;
	}

	/*Creation of the socket */
	int sock;
	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	//Evaluate for errors to make sure the socket is valid.
	if (sock < 0) {
		puts("Failure of socket creation!\n");
		return 0;
	}

	/* End creation of the socket */

	/*Socket server and Binding structure*/
	struct sockaddr_in server;
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_port = htons(PORT);

	if (bind(sock, (struct sockaddr*) &server, sizeof(server))
			< 0) {
		puts("Binding failed!\n");
		return 0;
	}

	/* End assignment of socket server and Binding structure*/

	/* Setting of the listening socket */
	while (1) {

		puts("\t\t\t *SERVER*\n");
		puts("\n Waiting for client... \n");

		struct sockaddr_in client;
		struct hostent *hostClient;

		char echoMess[DIM_BUFFER];
		int lenght_client = sizeof(client);
		recvfrom(sock, echoMess, sizeof(echoMess), 0, (struct sockaddr*) &client, &lenght_client);

		hostClient = gethostbyaddr((char *) &client.sin_addr, 4, AF_INET);
		char* nameClient = hostClient->h_name;
		sendto(sock, echoMess, sizeof(echoMess), 0,(struct sockaddr*) &client, sizeof(client));

		/*input values*/
		messagge_t m;
		int flag = 0;

		/*Struct reception and processing of strings*/
		do {

			if (recvfrom(sock,(void*) &m, sizeof(messagge_t), 0,(struct sockaddr*) &client, &lenght_client) < 0) {

				closesocket(sock);
				puts("Reception failed; end of program. ");
				system("PAUSE");
				return 0;
			}


			 struct in_addr **addr_list;

			 printf("Operation requested [%c %.2f %.2f] from client  %s , ",m.op, m.num1,m.num2, hostClient->h_name );
			 printf("IP ");
			 addr_list = (struct in_addr **)hostClient->h_addr_list;
			 for( int i = 0; addr_list[i] != NULL; i++) {
			  printf(" %s ", inet_ntoa(*addr_list[i]));
			 }



			switch(m.op)
					{
						case '+' :	result=add(m.num1, m.num2);
									printf("\n [ %.2f + %.2f = %.2f ] \n", m.num1,m.num2,result);
									break;
						case '-' :	result=sub(m.num1, m.num2);
									printf("\n [ %.2f - %.2f = %.2f ] \n", m.num1,m.num2,result);
									break;
						case '*' :  result=mult(m.num1, m.num2);
									printf("\n [ %.2f * %.2f = %.2f ] \n", m.num1,m.num2,result);
									break;
						case '/' :  result=division(m.num1, m.num2);
									printf("\n [ %.2f / %.2f = %.2f ] \n", m.num1,m.num2,result);
									break;
						case '=':   flag=1;
						            break;

						/*Control invalid operation */
						default:   printf("\nInvalid operation. Send operation correct..\n");
								   break;
					}

			if (sendto(sock,(void*) &m, sizeof(messagge_t), 0 , (struct sockaddr*) &client, sizeof(client)) < 0) {

				closesocket(sock);
				puts("Sending failed; end of program.");
				system("PAUSE");
				return 0;
			}

			if (sendto(sock,(void*)&result, sizeof(float), 0 , (struct sockaddr*) &client, sizeof(client)) < 0) {

				closesocket(sock);
				puts("Sending failed; end of program.");
				system("PAUSE");
				return 0;
			}

		} while (flag == 0);

		printf ("\nConnection closed with client %s\n\n", nameClient);

	} //while loop to keep it active

	/*End of connection*/

	closesocket(sock);
	ClearWinSock();
	system("pause");
	return 0;

}

/*functions*/

float add(float number1, float number2)
{
	result=number1+number2;
return result;
}
float sub(float number1, float number2)
{
	result=number1-number2;
	return result;
}
float mult(float number1, float number2)
{
	result=number1*number2;
	return result;
}
float division(float number1, float number2)
{
	result=(number1/number2);
	return result;
}
