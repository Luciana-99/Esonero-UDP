#ifndef PROTOCOL_SERVER_H_
#define PROTOCOL_SERVER_H_
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>


#define DIM_BUFFER 256
#define PORT 56700

void ClearWinSock() {

#if defined WIN32
	WSACleanup();
#endif

}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	/*WsaData's initialization*/
	WSADATA wsaData;
	int init = WSAStartup(MAKEWORD(2, 2), &wsaData);

	if (init != 0) {

		puts("\nWSAStartup () initialization error!");
		return 0;
	}

	/*Creation of the socket */
	int sock;
	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	//Evaluate for errors to make sure the socket is valid.
	if (sock < 0) {
		puts("Failure of socket creation!\n");
		return 0;
	}

	/*Socket server and Binding structure*/
	struct sockaddr_in server;
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_port = htons(PORT);

	if (bind(sock, (struct sockaddr*) &server, sizeof(server))
			< 0) {
		puts("Binding failed!\n");
		return 0;
	}

	/* Setting of the listening socket */
	while (1) {

		puts("\t\t\t *SERVER*\n");
		puts("\n Waiting for client... \n");

		struct sockaddr_in client;
		struct hostent *hostClient;

		char echoMess[DIM_BUFFER];
		int lenght_client = sizeof(client);


		recvfrom(sock, echoMess, sizeof(echoMess), 0, (struct sockaddr*) &client, &lenght_client);

		hostClient = gethostbyaddr((char *) &client.sin_addr, 4, AF_INET);
		char* nameClient = hostClient->h_name;
}

	system ("pause");
	ClearWinSock();
	return 0;
}

#endif /* PROTOCOL_SERVER_H_ */
